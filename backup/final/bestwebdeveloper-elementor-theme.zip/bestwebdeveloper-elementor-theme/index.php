<?php
/**
 * Index template.
 *
 * @package BestWebDeveloper
 */
get_header();
?>
<section class="bwd-default-content">
  <div class="container-xl">
    <?php if ( have_posts() ) : ?>
      <div class="row g-4">
        <?php while ( have_posts() ) : the_post(); ?>
          <div class="col-md-6 col-xl-4">
            <article <?php post_class( 'blog-card h-100' ); ?>>
              <?php if ( has_post_thumbnail() ) : ?><a class="blog-img" href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'large' ); ?></a><?php endif; ?>
              <div class="p-4">
                <span class="blog-cat"><?php echo esc_html( get_the_date() ); ?></span>
                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                <p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 24 ) ); ?></p>
              </div>
            </article>
          </div>
        <?php endwhile; ?>
      </div>
      <div class="mt-5"><?php the_posts_pagination(); ?></div>
    <?php else : ?>
      <h1><?php esc_html_e( 'Nothing found', 'bestwebdeveloper' ); ?></h1>
      <p><?php esc_html_e( 'Please run the Best Web Developer importer to generate the full website.', 'bestwebdeveloper' ); ?></p>
    <?php endif; ?>
  </div>
</section>
<?php
get_footer();
