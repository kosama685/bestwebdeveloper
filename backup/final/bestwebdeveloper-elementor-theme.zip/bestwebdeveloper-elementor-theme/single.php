<?php
/**
 * Single post template.
 *
 * @package BestWebDeveloper
 */
get_header();
while ( have_posts() ) : the_post();
    ?>
    <article id="post-<?php the_ID(); ?>" <?php post_class( 'bwd-wp-content' ); ?>>
      <?php the_content(); ?>
    </article>
    <?php
endwhile;
get_footer();
