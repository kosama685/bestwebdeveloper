<?php
/**
 * Theme header.
 *
 * @package BestWebDeveloper
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#ff8c00">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?> data-bs-spy="scroll" data-bs-target="#mainNav" data-bs-offset="120">
<?php wp_body_open(); ?>
<a href="#main" class="skip-link"><?php esc_html_e( 'Skip to content', 'bestwebdeveloper' ); ?></a>
<div class="top-progress" id="topProgress"></div>
<nav class="navbar navbar-expand-xl fixed-top nav-glass" id="mainNav" aria-label="<?php esc_attr_e( 'Primary navigation', 'bestwebdeveloper' ); ?>">
  <div class="container-xl">
    <a class="navbar-brand d-flex align-items-center gap-2" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?> Home">
      <?php echo bwd_theme_logo_markup( 'brand-logo' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
    </a>
    <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle navigation', 'bestwebdeveloper' ); ?>">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarContent">
      <?php
      if ( has_nav_menu( 'primary' ) ) {
          wp_nav_menu( array(
              'theme_location' => 'primary',
              'container'      => false,
              'menu_class'     => 'navbar-nav ms-auto align-items-xl-center gap-xl-1',
              'fallback_cb'    => false,
              'walker'         => new BWD_Bootstrap_Navwalker(),
              'depth'          => 2,
          ) );
      } else {
          bwd_fallback_primary_menu();
      }
      ?>
      <div class="ms-xl-3 mt-3 mt-xl-0">
        <a href="<?php echo esc_url( get_theme_mod( 'bwd_cta_url', home_url( '/contact/' ) ) ); ?>" class="btn btn-orange btn-sm rounded-pill px-4 magnetic-btn"><?php echo esc_html( get_theme_mod( 'bwd_cta_text', 'Free Consultation' ) ); ?></a>
      </div>
    </div>
  </div>
</nav>
<main id="main" class="site-main">
