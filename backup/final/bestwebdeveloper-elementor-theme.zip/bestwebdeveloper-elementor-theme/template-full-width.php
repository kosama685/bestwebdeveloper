<?php
/**
 * Template Name: BWD Full Width Elementor
 * Template Post Type: page, post
 *
 * @package BestWebDeveloper
 */
get_header();
while ( have_posts() ) :
    the_post();
    ?>
    <article id="post-<?php the_ID(); ?>" <?php post_class( 'bwd-wp-content' ); ?>>
        <?php the_content(); ?>
    </article>
    <?php
endwhile;
get_footer();
