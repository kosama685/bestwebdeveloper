<?php
/**
 * 404 template.
 *
 * @package BestWebDeveloper
 */
get_header();
?>
<section class="hero-corporate position-relative overflow-hidden">
  <div class="container-xl position-relative">
    <div class="row align-items-center min-vh-100 py-5 g-5">
      <div class="col-lg-8 pt-5" data-aos="fade-right">
        <span class="eyebrow"><i class="bi bi-exclamation-triangle-fill"></i> 404</span>
        <h1 class="display-4 fw-black mt-3 mb-4"><?php esc_html_e( 'Page not found', 'bestwebdeveloper' ); ?></h1>
        <p class="lead text-white-75 mb-4"><?php esc_html_e( 'The page you requested was moved or does not exist. Return home or explore our services.', 'bestwebdeveloper' ); ?></p>
        <div class="d-flex flex-wrap gap-3"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn-orange btn-lg rounded-pill magnetic-btn"><?php esc_html_e( 'Go Home', 'bestwebdeveloper' ); ?></a><a href="<?php echo esc_url( home_url( '/services/' ) ); ?>" class="btn btn-outline-light btn-lg rounded-pill"><?php esc_html_e( 'Explore Services', 'bestwebdeveloper' ); ?></a></div>
      </div>
    </div>
  </div>
</section>
<?php
get_footer();
