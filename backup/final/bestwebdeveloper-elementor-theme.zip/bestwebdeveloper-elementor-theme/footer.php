<?php
/**
 * Theme footer.
 *
 * @package BestWebDeveloper
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
</main>
<footer class="footer-creative pt-5">
  <div class="container-xl py-5">
    <div class="row g-4">
      <div class="col-lg-4" data-aos="fade-up">
        <?php echo bwd_theme_logo_markup( 'footer-logo mb-4' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
        <p class="text-white-50"><?php echo esc_html( get_theme_mod( 'bwd_footer_summary', 'A corporate web design, development, branding, SEO, and digital marketing partner for companies that want premium design and measurable digital growth.' ) ); ?></p>
        <div class="d-flex gap-2 mt-4 social-icons">
          <a href="<?php echo esc_url( get_theme_mod( 'bwd_facebook_url', '#' ) ); ?>" aria-label="Facebook"><i class="bi bi-facebook"></i></a>
          <a href="<?php echo esc_url( get_theme_mod( 'bwd_linkedin_url', '#' ) ); ?>" aria-label="LinkedIn"><i class="bi bi-linkedin"></i></a>
          <a href="<?php echo esc_url( get_theme_mod( 'bwd_instagram_url', '#' ) ); ?>" aria-label="Instagram"><i class="bi bi-instagram"></i></a>
          <a href="<?php echo esc_url( get_theme_mod( 'bwd_youtube_url', '#' ) ); ?>" aria-label="YouTube"><i class="bi bi-youtube"></i></a>
        </div>
      </div>
      <div class="col-6 col-lg-2" data-aos="fade-up" data-aos-delay="50">
        <h3 class="footer-title"><?php esc_html_e( 'Company', 'bestwebdeveloper' ); ?></h3>
        <?php
        wp_nav_menu( array(
            'theme_location' => 'footer',
            'container'      => false,
            'menu_class'     => 'footer-list',
            'fallback_cb'    => function() {
                echo '<ul class="footer-list"><li><a href="' . esc_url( home_url( '/about/' ) ) . '">About</a></li><li><a href="' . esc_url( home_url( '/portfolio/' ) ) . '">Portfolio</a></li><li><a href="' . esc_url( home_url( '/testimonials/' ) ) . '">Testimonials</a></li><li><a href="' . esc_url( home_url( '/blog/' ) ) . '">Blog</a></li><li><a href="' . esc_url( home_url( '/faq/' ) ) . '">FAQs</a></li></ul>';
            },
            'depth'          => 1,
        ) );
        ?>
      </div>
      <div class="col-6 col-lg-3" data-aos="fade-up" data-aos-delay="100">
        <h3 class="footer-title"><?php esc_html_e( 'Services', 'bestwebdeveloper' ); ?></h3>
        <?php
        wp_nav_menu( array(
            'theme_location' => 'footer_services',
            'container'      => false,
            'menu_class'     => 'footer-list two-col',
            'fallback_cb'    => function() {
                echo '<ul class="footer-list two-col"><li><a href="' . esc_url( home_url( '/services/web-design-development/' ) ) . '">Web Design &amp; Development</a></li><li><a href="' . esc_url( home_url( '/services/search-engine-optimization-services/' ) ) . '">SEO Services</a></li><li><a href="' . esc_url( home_url( '/services/digital-marketing-services/' ) ) . '">Digital Marketing</a></li><li><a href="' . esc_url( home_url( '/services/social-media-agency/' ) ) . '">Social Media</a></li></ul>';
            },
            'depth'          => 1,
        ) );
        ?>
      </div>
      <div class="col-lg-3" data-aos="fade-up" data-aos-delay="150">
        <?php if ( is_active_sidebar( 'footer-contact' ) ) : ?>
          <?php dynamic_sidebar( 'footer-contact' ); ?>
        <?php else : ?>
          <h3 class="footer-title"><?php esc_html_e( 'Start a project', 'bestwebdeveloper' ); ?></h3>
          <p class="text-white-50"><?php esc_html_e( 'Tell us about your goals and receive a strategy-first consultation.', 'bestwebdeveloper' ); ?></p>
          <a class="btn btn-orange rounded-pill w-100" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Request Free Quote', 'bestwebdeveloper' ); ?></a>
          <div class="mt-4 small text-white-50"><?php echo esc_html( get_theme_mod( 'bwd_service_regions', 'USA & UK service coverage' ) ); ?><br><?php echo esc_html( get_theme_mod( 'bwd_contact_email', 'hello@bestwebdeveloper.org' ) ); ?></div>
        <?php endif; ?>
      </div>
    </div>
    <div class="footer-bottom d-flex flex-wrap justify-content-between gap-3 mt-5 pt-4">
      <span>© <?php echo esc_html( date_i18n( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?>. <?php esc_html_e( 'All rights reserved.', 'bestwebdeveloper' ); ?></span>
      <span>
        <?php
        $locations = get_nav_menu_locations();
        if ( ! empty( $locations['footer_legal'] ) ) {
            $legal_items = wp_get_nav_menu_items( $locations['footer_legal'] );
            if ( $legal_items ) {
                $legal_links = array();
                foreach ( $legal_items as $legal_item ) {
                    $legal_links[] = '<a href="' . esc_url( $legal_item->url ) . '">' . esc_html( $legal_item->title ) . '</a>';
                }
                echo implode( ' · ', $legal_links ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            }
        } else {
            echo '<a href="' . esc_url( home_url( '/privacy-policy/' ) ) . '">Privacy</a> · <a href="' . esc_url( home_url( '/terms-conditions/' ) ) . '">Terms</a> · <a href="' . esc_url( home_url( '/cookie-policy/' ) ) . '">Cookies</a> · <a href="' . esc_url( home_url( '/sitemap/' ) ) . '">Sitemap</a>';
        }
        ?>
      </span>
    </div>
  </div>
</footer>
<button class="back-to-top" id="backToTop" aria-label="<?php esc_attr_e( 'Back to top', 'bestwebdeveloper' ); ?>"><i class="bi bi-arrow-up"></i></button>
<div class="cookie-card" id="cookieCard" role="dialog" aria-label="<?php esc_attr_e( 'Cookie notice', 'bestwebdeveloper' ); ?>">
  <div><strong><?php esc_html_e( 'Cookies & analytics.', 'bestwebdeveloper' ); ?></strong> <?php esc_html_e( 'This site includes a cookie notice placeholder so your developer can connect real consent tools.', 'bestwebdeveloper' ); ?></div>
  <button class="btn btn-orange btn-sm rounded-pill" id="acceptCookies"><?php esc_html_e( 'Accept', 'bestwebdeveloper' ); ?></button>
</div>
<?php wp_footer(); ?>
</body>
</html>
