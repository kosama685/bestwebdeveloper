<?php
/**
 * Best Web Developer Elementor Theme functions.
 *
 * @package BestWebDeveloper
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'BWD_THEME_VERSION', '1.0.0' );
define( 'BWD_THEME_DIR', get_template_directory() );
define( 'BWD_THEME_URI', get_template_directory_uri() );

if ( ! function_exists( 'bwd_theme_setup' ) ) {
    function bwd_theme_setup() {
        load_theme_textdomain( 'bestwebdeveloper', BWD_THEME_DIR . '/languages' );
        add_theme_support( 'title-tag' );
        add_theme_support( 'post-thumbnails' );
        add_theme_support( 'custom-logo', array(
            'height'      => 70,
            'width'       => 260,
            'flex-height' => true,
            'flex-width'  => true,
        ) );
        add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
        add_theme_support( 'automatic-feed-links' );
        add_theme_support( 'align-wide' );
        add_theme_support( 'responsive-embeds' );
        add_theme_support( 'editor-styles' );
        add_editor_style( 'assets/css/styles.css' );

        register_nav_menus( array(
            'primary'         => __( 'Primary Header Menu', 'bestwebdeveloper' ),
            'footer'          => __( 'Footer Company Menu', 'bestwebdeveloper' ),
            'footer_services' => __( 'Footer Services Menu', 'bestwebdeveloper' ),
            'footer_legal'    => __( 'Footer Legal Menu', 'bestwebdeveloper' ),
        ) );
    }
}
add_action( 'after_setup_theme', 'bwd_theme_setup' );

function bwd_theme_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Footer Contact', 'bestwebdeveloper' ),
        'id'            => 'footer-contact',
        'description'   => __( 'Optional footer contact widgets.', 'bestwebdeveloper' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="footer-title">',
        'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'bwd_theme_widgets_init' );

function bwd_theme_enqueue_assets() {
    wp_enqueue_style( 'bwd-google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Sora:wght@500;600;700;800&display=swap', array(), null );
    wp_enqueue_style( 'bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css', array(), '5.3.3' );
    wp_enqueue_style( 'bootstrap-icons', 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css', array(), '1.11.3' );
    wp_enqueue_style( 'aos', 'https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css', array(), '2.3.4' );
    wp_enqueue_style( 'bwd-main', BWD_THEME_URI . '/assets/css/styles.css', array( 'bootstrap', 'bootstrap-icons', 'aos' ), BWD_THEME_VERSION );
    wp_add_inline_style( 'bwd-main', '.admin-bar .nav-glass{top:32px}@media(max-width:782px){.admin-bar .nav-glass{top:46px}}.wp-block-post-content{margin:0}.bwd-wp-content>section:first-child{margin-top:0}.bwd-default-content{padding:140px 0 80px}.screen-reader-text{border:0;clip:rect(1px,1px,1px,1px);clip-path:inset(50%);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px;word-wrap:normal!important}' );

    wp_enqueue_script( 'bootstrap-bundle', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js', array(), '5.3.3', true );
    wp_enqueue_script( 'aos', 'https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js', array(), '2.3.4', true );
    wp_enqueue_script( 'bwd-main', BWD_THEME_URI . '/assets/js/main.js', array( 'bootstrap-bundle', 'aos' ), BWD_THEME_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'bwd_theme_enqueue_assets' );

function bwd_theme_customize_register( $wp_customize ) {
    $wp_customize->add_section( 'bwd_brand_options', array(
        'title'       => __( 'Best Web Developer Brand', 'bestwebdeveloper' ),
        'description' => __( 'Quick edit brand, CTA, contact and social footer settings.', 'bestwebdeveloper' ),
        'priority'    => 30,
    ) );

    $fields = array(
        'bwd_cta_text'        => array( 'Free Consultation', __( 'Header CTA Text', 'bestwebdeveloper' ) ),
        'bwd_cta_url'         => array( '/contact/', __( 'Header CTA URL', 'bestwebdeveloper' ) ),
        'bwd_footer_summary'  => array( 'A corporate web design, development, branding, SEO, and digital marketing partner for companies that want premium design and measurable digital growth.', __( 'Footer Summary', 'bestwebdeveloper' ) ),
        'bwd_contact_email'   => array( 'hello@bestwebdeveloper.org', __( 'Contact Email', 'bestwebdeveloper' ) ),
        'bwd_service_regions' => array( 'USA & UK service coverage', __( 'Service Regions', 'bestwebdeveloper' ) ),
        'bwd_facebook_url'    => array( '#', __( 'Facebook URL', 'bestwebdeveloper' ) ),
        'bwd_linkedin_url'    => array( '#', __( 'LinkedIn URL', 'bestwebdeveloper' ) ),
        'bwd_instagram_url'   => array( '#', __( 'Instagram URL', 'bestwebdeveloper' ) ),
        'bwd_youtube_url'     => array( '#', __( 'YouTube URL', 'bestwebdeveloper' ) ),
    );

    foreach ( $fields as $key => $data ) {
        $wp_customize->add_setting( $key, array(
            'default'           => $data[0],
            'sanitize_callback' => ( false !== strpos( $key, '_url' ) ) ? 'esc_url_raw' : 'sanitize_text_field',
        ) );
        $wp_customize->add_control( $key, array(
            'label'   => $data[1],
            'section' => 'bwd_brand_options',
            'type'    => 'text',
        ) );
    }
}
add_action( 'customize_register', 'bwd_theme_customize_register' );

function bwd_theme_logo_markup( $class = 'brand-logo' ) {
    if ( has_custom_logo() ) {
        $custom_logo_id = get_theme_mod( 'custom_logo' );
        $logo = wp_get_attachment_image_src( $custom_logo_id, 'full' );
        if ( ! empty( $logo[0] ) ) {
            return '<img src="' . esc_url( $logo[0] ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '" class="' . esc_attr( $class ) . '">';
        }
    }
    return '<img src="' . esc_url( BWD_THEME_URI . '/assets/images/best-web-developer-logo.png' ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . ' logo" class="' . esc_attr( $class ) . '">';
}

function bwd_schema_output() {
    if ( is_singular() ) {
        $schema = get_post_meta( get_the_ID(), 'bwd_schema_json', true );
        if ( $schema ) {
            echo "\n<script type=\"application/ld+json\">" . wp_kses_post( $schema ) . "</script>\n";
        }
    }
}
add_action( 'wp_head', 'bwd_schema_output', 20 );

function bwd_basic_meta_output() {
    if ( is_singular() ) {
        $description = get_post_meta( get_the_ID(), 'bwd_meta_description', true );
        if ( $description ) {
            echo '<meta name="description" content="' . esc_attr( $description ) . '">' . "\n";
        }
    }
}
add_action( 'wp_head', 'bwd_basic_meta_output', 4 );

/**
 * Minimal Bootstrap 5 dropdown nav walker.
 */
class BWD_Bootstrap_Navwalker extends Walker_Nav_Menu {
    public function start_lvl( &$output, $depth = 0, $args = null ) {
        $indent  = str_repeat( "\t", $depth );
        $classes = ( 0 === $depth ) ? 'dropdown-menu shadow-lg border-0 rounded-4 p-3' : 'dropdown-menu';
        $output .= "\n$indent<ul class=\"$classes\">\n";
    }

    public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
        $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';
        $classes = empty( $item->classes ) ? array() : (array) $item->classes;
        $has_children = in_array( 'menu-item-has-children', $classes, true );
        $li_classes = array( 'nav-item' );
        if ( $has_children && 0 === $depth ) {
            $li_classes[] = 'dropdown mega-dropdown';
        }
        if ( $depth > 0 ) {
            $li_classes = array();
        }
        $output .= $indent . '<li class="' . esc_attr( implode( ' ', array_filter( $li_classes ) ) ) . '">';

        $atts = array();
        $atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
        $atts['target'] = ! empty( $item->target ) ? $item->target : '';
        $atts['rel']    = ! empty( $item->xfn ) ? $item->xfn : '';
        $atts['href']   = ! empty( $item->url ) ? $item->url : '';
        $atts['class']  = ( 0 === $depth ) ? 'nav-link' : 'dropdown-item rounded-3';
        if ( $has_children && 0 === $depth ) {
            $atts['class'] .= ' dropdown-toggle';
            $atts['role'] = 'button';
            $atts['data-bs-toggle'] = 'dropdown';
            $atts['aria-expanded'] = 'false';
        }

        $attributes = '';
        foreach ( $atts as $attr => $value ) {
            if ( ! empty( $value ) ) {
                $value = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
                $attributes .= ' ' . $attr . '="' . $value . '"';
            }
        }

        $title = apply_filters( 'the_title', $item->title, $item->ID );
        $item_output  = isset( $args->before ) ? $args->before : '';
        $item_output .= '<a' . $attributes . '>';
        if ( $depth > 0 ) {
            $item_output .= '<i class="bi bi-check-circle me-2 text-orange"></i>';
        }
        $item_output .= ( isset( $args->link_before ) ? $args->link_before : '' ) . $title . ( isset( $args->link_after ) ? $args->link_after : '' );
        $item_output .= '</a>';
        $item_output .= isset( $args->after ) ? $args->after : '';
        $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
    }
}

function bwd_fallback_primary_menu() {
    $items = array(
        'Home' => home_url( '/' ),
        'About' => home_url( '/about/' ),
        'Services' => home_url( '/services/' ),
        'Portfolio' => home_url( '/portfolio/' ),
        'Pricing' => home_url( '/pricing/' ),
        'Blog' => home_url( '/blog/' ),
        'FAQs' => home_url( '/faq/' ),
        'Contact' => home_url( '/contact/' ),
    );
    echo '<ul class="navbar-nav ms-auto align-items-xl-center gap-xl-1">';
    foreach ( $items as $label => $url ) {
        echo '<li class="nav-item"><a class="nav-link" href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a></li>';
    }
    echo '</ul>';
}
