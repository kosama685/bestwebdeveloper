<?php
/**
 * Plugin Name: Best Web Developer Site Importer
 * Plugin URI: https://bestwebdeveloper.org/
 * Description: One-click importer for the Best Web Developer Elementor corporate theme. Creates all pages, service pages, blog posts, portfolio pages, dynamic menus, front page, Elementor page data, SEO metadata, schema, header/footer template records, and image/asset links.
 * Version: 1.0.0
 * Author: Best Web Developer
 * Author URI: https://bestwebdeveloper.org/
 * License: GPL-2.0-or-later
 * Text Domain: bestwebdeveloper-importer
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'BWD_IMPORTER_VERSION', '1.0.0' );
define( 'BWD_IMPORTER_DIR', plugin_dir_path( __FILE__ ) );
define( 'BWD_IMPORTER_URL', plugin_dir_url( __FILE__ ) );

class BWD_Site_Importer {
    const OPTION_LAST_RESULT = 'bwd_importer_last_result';
    const OPTION_IMPORTED    = 'bwd_importer_imported';

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
        add_action( 'admin_post_bwd_run_import', array( $this, 'handle_import' ) );
        add_action( 'admin_notices', array( $this, 'admin_notice' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'fallback_enqueue_assets' ) );
        register_activation_hook( __FILE__, array( __CLASS__, 'activate' ) );
    }

    public static function activate() {
        set_transient( 'bwd_importer_activation_notice', 1, 90 );
    }

    public function admin_notice() {
        if ( ! current_user_can( 'manage_options' ) || ! get_transient( 'bwd_importer_activation_notice' ) ) {
            return;
        }
        delete_transient( 'bwd_importer_activation_notice' );
        $url = admin_url( 'themes.php?page=bwd-site-importer' );
        echo '<div class="notice notice-success is-dismissible"><p><strong>Best Web Developer Importer:</strong> Ready. <a class="button button-primary" href="' . esc_url( $url ) . '">Generate the full Elementor website</a></p></div>';
    }

    public function admin_menu() {
        add_theme_page(
            __( 'BWD Site Importer', 'bestwebdeveloper-importer' ),
            __( 'BWD Site Importer', 'bestwebdeveloper-importer' ),
            'manage_options',
            'bwd-site-importer',
            array( $this, 'render_admin_page' )
        );
    }

    public function render_admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $data   = $this->load_data();
        $result = get_option( self::OPTION_LAST_RESULT );
        $is_theme_active = ( 'bestwebdeveloper-elementor-theme' === get_stylesheet() || 'bestwebdeveloper-elementor-theme' === get_template() );
        ?>
        <div class="wrap">
            <h1>Best Web Developer Elementor Website Importer</h1>
            <p>This importer creates the complete corporate website from the supplied HTML package: pages, service pages, blog posts, portfolio items, menus, header/footer settings, Elementor-editable sections, schema, and SEO metadata.</p>
            <div style="background:#fff;border:1px solid #dcdcde;border-left:4px solid #ff8c00;padding:16px;margin:18px 0;max-width:920px;">
                <p><strong>Package status:</strong> <?php echo esc_html( $data['total'] ?? 0 ); ?> content items ready.</p>
                <p><strong>Theme status:</strong> <?php echo $is_theme_active ? '<span style="color:#008a20;font-weight:700;">Best Web Developer Elementor Theme is active</span>' : '<span style="color:#b32d2e;font-weight:700;">Please activate Best Web Developer Elementor Theme for the exact header/footer and design system.</span>'; ?></p>
                <p><strong>Elementor status:</strong> <?php echo did_action( 'elementor/loaded' ) ? '<span style="color:#008a20;font-weight:700;">Elementor detected</span>' : '<span style="color:#996800;font-weight:700;">Elementor not active. Pages will still import as HTML fallback and become Elementor-ready once Elementor is installed.</span>'; ?></p>
            </div>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <?php wp_nonce_field( 'bwd_run_import_action', 'bwd_run_import_nonce' ); ?>
                <input type="hidden" name="action" value="bwd_run_import">
                <p><label><input type="checkbox" name="overwrite" value="1" checked> Update existing imported pages/posts if they already exist</label></p>
                <p><button type="submit" class="button button-primary button-hero">Generate / Update Full Website</button></p>
            </form>
            <?php if ( is_array( $result ) ) : ?>
                <h2>Last Import Result</h2>
                <table class="widefat striped" style="max-width:920px;">
                    <tbody>
                        <tr><th>Completed</th><td><?php echo esc_html( $result['time'] ?? '' ); ?></td></tr>
                        <tr><th>Pages created/updated</th><td><?php echo esc_html( $result['pages'] ?? 0 ); ?></td></tr>
                        <tr><th>Posts created/updated</th><td><?php echo esc_html( $result['posts'] ?? 0 ); ?></td></tr>
                        <tr><th>Menus</th><td><?php echo esc_html( $result['menus'] ?? '' ); ?></td></tr>
                        <tr><th>Front Page</th><td><?php echo esc_html( $result['front_page'] ?? '' ); ?></td></tr>
                    </tbody>
                </table>
            <?php endif; ?>
            <h2>Included content</h2>
            <p>The importer includes all top-level pages, legal pages, service pages, portfolio entries, blog posts, and regional landing pages from the package.</p>
        </div>
        <?php
    }

    public function handle_import() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Permission denied.', 'bestwebdeveloper-importer' ) );
        }
        check_admin_referer( 'bwd_run_import_action', 'bwd_run_import_nonce' );
        $overwrite = ! empty( $_POST['overwrite'] );
        $result = $this->run_import( $overwrite );
        update_option( self::OPTION_LAST_RESULT, $result, false );
        wp_safe_redirect( admin_url( 'themes.php?page=bwd-site-importer&imported=1' ) );
        exit;
    }

    public function fallback_enqueue_assets() {
        if ( 'bestwebdeveloper-elementor-theme' === get_template() || 'bestwebdeveloper-elementor-theme' === get_stylesheet() ) {
            return;
        }
        wp_enqueue_style( 'bwd-importer-google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Sora:wght@500;600;700;800&display=swap', array(), null );
        wp_enqueue_style( 'bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css', array(), '5.3.3' );
        wp_enqueue_style( 'bootstrap-icons', 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css', array(), '1.11.3' );
        wp_enqueue_style( 'aos', 'https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css', array(), '2.3.4' );
        wp_enqueue_style( 'bwd-importer-main', BWD_IMPORTER_URL . 'assets/css/styles.css', array( 'bootstrap', 'bootstrap-icons', 'aos' ), BWD_IMPORTER_VERSION );
        wp_enqueue_script( 'bootstrap-bundle', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js', array(), '5.3.3', true );
        wp_enqueue_script( 'aos', 'https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js', array(), '2.3.4', true );
        wp_enqueue_script( 'bwd-importer-main', BWD_IMPORTER_URL . 'assets/js/main.js', array( 'bootstrap-bundle', 'aos' ), BWD_IMPORTER_VERSION, true );
    }

    private function load_data() {
        $file = BWD_IMPORTER_DIR . 'data/pages.json';
        if ( ! file_exists( $file ) ) {
            return array( 'total' => 0, 'pages' => array() );
        }
        $json = file_get_contents( $file );
        $data = json_decode( $json, true );
        return is_array( $data ) ? $data : array( 'total' => 0, 'pages' => array() );
    }

    private function get_asset_base_url() {
        $theme_dir = trailingslashit( get_theme_root() ) . 'bestwebdeveloper-elementor-theme/assets';
        if ( file_exists( $theme_dir ) ) {
            return trailingslashit( get_theme_root_uri() . '/bestwebdeveloper-elementor-theme/assets' );
        }
        return trailingslashit( BWD_IMPORTER_URL . 'assets' );
    }

    public function run_import( $overwrite = true ) {
        $data = $this->load_data();
        if ( empty( $data['pages'] ) ) {
            return array( 'time' => current_time( 'mysql' ), 'pages' => 0, 'posts' => 0, 'menus' => 'No data found', 'front_page' => '' );
        }

        $asset_base = $this->get_asset_base_url();
        $created_ids = array();
        $page_count = 0;
        $post_count = 0;

        // Create/update parent/top-level pages first so children can attach cleanly.
        $items = $data['pages'];
        usort( $items, function( $a, $b ) {
            $aw = empty( $a['parent'] ) ? 0 : 1;
            $bw = empty( $b['parent'] ) ? 0 : 1;
            if ( $aw === $bw ) {
                return strcmp( $a['source'], $b['source'] );
            }
            return $aw - $bw;
        } );

        foreach ( $items as $item ) {
            $post_id = $this->upsert_post_shell( $item, $created_ids, $overwrite );
            if ( $post_id ) {
                $created_ids[ $item['source'] ] = $post_id;
                $created_ids[ $item['slug'] ] = $post_id;
                if ( 'post' === $item['type'] ) {
                    $post_count++;
                } else {
                    $page_count++;
                }
            }
        }

        $link_map = $this->build_link_map( $items, $created_ids );

        foreach ( $items as $item ) {
            $post_id = $created_ids[ $item['source'] ] ?? 0;
            if ( ! $post_id ) {
                continue;
            }
            $content = $this->rewrite_content( $item['content'], $item['source'], $link_map, $asset_base );
            $schema  = $this->rewrite_schema( $item['schema'], $link_map, $asset_base );
            wp_update_post( array(
                'ID'           => $post_id,
                'post_content' => wp_slash( $content ),
                'post_excerpt' => sanitize_text_field( $item['excerpt'] ?? '' ),
            ) );
            $this->update_meta( $post_id, $item, $content, $schema );
        }

        $this->create_categories();
        $this->assign_blog_categories( $items, $created_ids );
        $menu_result = $this->create_menus( $created_ids );
        $front_result = $this->configure_site( $created_ids );
        $this->create_elementor_templates( $created_ids, $link_map, $asset_base );
        flush_rewrite_rules( false );
        update_option( self::OPTION_IMPORTED, 1, false );

        return array(
            'time'       => current_time( 'mysql' ),
            'pages'      => $page_count,
            'posts'      => $post_count,
            'menus'      => $menu_result,
            'front_page' => $front_result,
        );
    }

    private function upsert_post_shell( $item, $created_ids, $overwrite ) {
        $type = ( 'post' === $item['type'] ) ? 'post' : 'page';
        $existing = $this->find_existing_post( $item['slug'], $type );
        if ( $existing && ! $overwrite ) {
            return (int) $existing->ID;
        }
        $parent_id = 0;
        if ( ! empty( $item['parent'] ) ) {
            $parent_id = $created_ids[ $item['parent'] ] ?? 0;
        }
        $postarr = array(
            'post_title'   => wp_strip_all_tags( $item['title'] ),
            'post_name'    => sanitize_title( $item['slug'] ),
            'post_status'  => 'publish',
            'post_type'    => $type,
            'post_parent'  => $parent_id,
            'post_content' => '',
            'post_excerpt' => sanitize_text_field( $item['excerpt'] ?? '' ),
        );
        if ( $existing ) {
            $postarr['ID'] = (int) $existing->ID;
            $post_id = wp_update_post( wp_slash( $postarr ), true );
        } else {
            $post_id = wp_insert_post( wp_slash( $postarr ), true );
        }
        if ( is_wp_error( $post_id ) ) {
            return 0;
        }
        return (int) $post_id;
    }

    private function find_existing_post( $slug, $post_type ) {
        $posts = get_posts( array(
            'name'           => sanitize_title( $slug ),
            'post_type'      => $post_type,
            'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
            'posts_per_page' => 1,
            'fields'         => 'all',
        ) );
        return ! empty( $posts ) ? $posts[0] : null;
    }

    private function build_link_map( $items, $created_ids ) {
        $map = array();
        foreach ( $items as $item ) {
            $post_id = $created_ids[ $item['source'] ] ?? 0;
            if ( ! $post_id ) {
                continue;
            }
            $url = get_permalink( $post_id );
            $map[ $item['source'] ] = $url;
            $map[ ltrim( $item['source'], './' ) ] = $url;
            $map[ $item['slug'] . '.html' ] = $url;
            $map[ $item['slug'] ] = $url;
            if ( 'index.html' === $item['source'] ) {
                $map['/'] = home_url( '/' );
                $map['index.html'] = home_url( '/' );
            }
        }
        return $map;
    }

    private function rewrite_content( $content, $source, $link_map, $asset_base ) {
        $content = str_replace( array( 'src="assets/', 'src="../assets/', "src='assets/", "src='../assets/" ), array( 'src="' . esc_url( $asset_base ), 'src="' . esc_url( $asset_base ), "src='" . esc_url( $asset_base ), "src='" . esc_url( $asset_base ) ), $content );
        $content = str_replace( array( 'href="assets/', 'href="../assets/', "href='assets/", "href='../assets/" ), array( 'href="' . esc_url( $asset_base ), 'href="' . esc_url( $asset_base ), "href='" . esc_url( $asset_base ), "href='" . esc_url( $asset_base ) ), $content );

        $self = $this;
        $content = preg_replace_callback( '/\b(href|src)=("|\')([^"\']+)(\2)/i', function( $matches ) use ( $source, $link_map, $asset_base, $self ) {
            $attr = $matches[1];
            $quote = $matches[2];
            $url = html_entity_decode( $matches[3] );
            $new = $self->resolve_relative_url( $url, $source, $link_map );
            return $attr . '=' . $quote . esc_url( $new ) . $quote;
        }, $content );

        return $content;
    }

    public function resolve_relative_url( $url, $source, $link_map ) {
        if ( '' === $url || preg_match( '#^(https?:|mailto:|tel:|sms:|javascript:|#|data:)#i', $url ) ) {
            return $url;
        }
        $parts = wp_parse_url( $url );
        $path = $parts['path'] ?? $url;
        $query = isset( $parts['query'] ) ? '?' . $parts['query'] : '';
        $fragment = isset( $parts['fragment'] ) ? '#' . $parts['fragment'] : '';
        if ( isset( $link_map[ $path ] ) ) {
            return $link_map[ $path ] . $query . $fragment;
        }
        $base = dirname( $source );
        $combined = ( '.' === $base ) ? $path : $base . '/' . $path;
        $normalized = $this->normalize_path( $combined );
        if ( isset( $link_map[ $normalized ] ) ) {
            return $link_map[ $normalized ] . $query . $fragment;
        }
        return $url;
    }

    private function normalize_path( $path ) {
        $parts = array();
        foreach ( explode( '/', str_replace( '\\', '/', $path ) ) as $part ) {
            if ( '' === $part || '.' === $part ) {
                continue;
            }
            if ( '..' === $part ) {
                array_pop( $parts );
            } else {
                $parts[] = $part;
            }
        }
        return implode( '/', $parts );
    }

    private function rewrite_schema( $schemas, $link_map, $asset_base ) {
        if ( empty( $schemas ) || ! is_array( $schemas ) ) {
            return '';
        }
        $joined = implode( "\n", $schemas );
        $joined = str_replace( 'https://bestwebdeveloper.org/assets/', esc_url_raw( $asset_base ), $joined );
        foreach ( $link_map as $old => $new ) {
            if ( preg_match( '/\.html$/', $old ) ) {
                $joined = str_replace( 'https://bestwebdeveloper.org/' . $old, $new, $joined );
            }
        }
        return $joined;
    }

    private function update_meta( $post_id, $item, $content, $schema ) {
        update_post_meta( $post_id, '_wp_page_template', 'template-full-width.php' );
        update_post_meta( $post_id, 'bwd_source_file', sanitize_text_field( $item['source'] ) );
        update_post_meta( $post_id, 'bwd_meta_description', sanitize_text_field( $item['meta_description'] ?? '' ) );
        update_post_meta( $post_id, 'bwd_schema_json', $schema );
        update_post_meta( $post_id, '_yoast_wpseo_title', wp_strip_all_tags( $item['title'] ) );
        update_post_meta( $post_id, '_yoast_wpseo_metadesc', sanitize_text_field( $item['meta_description'] ?? '' ) );
        update_post_meta( $post_id, 'rank_math_title', wp_strip_all_tags( $item['title'] ) );
        update_post_meta( $post_id, 'rank_math_description', sanitize_text_field( $item['meta_description'] ?? '' ) );
        update_post_meta( $post_id, '_aioseo_title', wp_strip_all_tags( $item['title'] ) );
        update_post_meta( $post_id, '_aioseo_description', sanitize_text_field( $item['meta_description'] ?? '' ) );
        update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
        update_post_meta( $post_id, '_elementor_template_type', ( 'post' === get_post_type( $post_id ) ) ? 'wp-post' : 'wp-page' );
        update_post_meta( $post_id, '_elementor_version', '3.28.0' );
        update_post_meta( $post_id, '_elementor_page_settings', array(
            'hide_title' => 'yes',
            'page_layout' => 'default',
        ) );
        update_post_meta( $post_id, '_elementor_data', wp_slash( wp_json_encode( $this->build_elementor_data( $content, $post_id ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) ) );
    }

    private function build_elementor_data( $content, $post_id ) {
        $sections = array();
        if ( preg_match_all( '/<section\b[^>]*>.*?<\/section>/is', $content, $matches ) && ! empty( $matches[0] ) ) {
            $sections = $matches[0];
        } else {
            $sections = array( $content );
        }
        $data = array();
        $i = 0;
        foreach ( $sections as $section_html ) {
            $sid = substr( md5( $post_id . '-section-' . $i ), 0, 7 );
            $cid = substr( md5( $post_id . '-column-' . $i ), 0, 7 );
            $wid = substr( md5( $post_id . '-widget-' . $i ), 0, 7 );
            $data[] = array(
                'id'       => $sid,
                'elType'   => 'section',
                'settings' => array(
                    'layout'          => 'full_width',
                    'gap'             => 'no',
                    'stretch_section' => 'section-stretched',
                    'css_classes'     => 'bwd-imported-elementor-section',
                ),
                'elements' => array(
                    array(
                        'id'       => $cid,
                        'elType'   => 'column',
                        'settings' => array( '_column_size' => 100 ),
                        'elements' => array(
                            array(
                                'id'         => $wid,
                                'elType'     => 'widget',
                                'widgetType' => 'html',
                                'settings'   => array( 'html' => $section_html ),
                                'elements'   => array(),
                            ),
                        ),
                        'isInner'  => false,
                    ),
                ),
                'isInner'  => false,
            );
            $i++;
        }
        return $data;
    }

    private function create_categories() {
        $cats = array( 'SEO', 'GEO', 'Web Design', 'Email Marketing', 'Social Media', 'Ecommerce', 'Branding', 'Technical SEO' );
        foreach ( $cats as $cat ) {
            if ( ! term_exists( $cat, 'category' ) ) {
                wp_insert_term( $cat, 'category' );
            }
        }
    }

    private function assign_blog_categories( $items, $created_ids ) {
        $rules = array(
            'seo'        => 'SEO',
            'geo'        => 'GEO',
            'responsive' => 'Web Design',
            'bootstrap'  => 'Web Design',
            'email'      => 'Email Marketing',
            'social'     => 'Social Media',
            'shopify'    => 'Ecommerce',
            'brand'      => 'Branding',
            'technical'  => 'Technical SEO',
        );
        foreach ( $items as $item ) {
            if ( 'post' !== $item['type'] ) {
                continue;
            }
            $post_id = $created_ids[ $item['source'] ] ?? 0;
            if ( ! $post_id ) {
                continue;
            }
            $cats = array();
            foreach ( $rules as $needle => $cat ) {
                if ( false !== strpos( $item['slug'], $needle ) || false !== stripos( $item['title'], $needle ) ) {
                    $term = get_term_by( 'name', $cat, 'category' );
                    if ( $term ) {
                        $cats[] = (int) $term->term_id;
                    }
                }
            }
            if ( empty( $cats ) ) {
                $term = get_term_by( 'name', 'Web Design', 'category' );
                if ( $term ) {
                    $cats[] = (int) $term->term_id;
                }
            }
            wp_set_post_categories( $post_id, array_unique( $cats ), false );
        }
    }

    private function create_menus( $ids ) {
        $primary_id = $this->reset_menu( 'Best Web Developer Main Menu' );
        $footer_id  = $this->reset_menu( 'Best Web Developer Footer Menu' );
        $services_id = $this->reset_menu( 'Best Web Developer Footer Services' );
        $legal_id   = $this->reset_menu( 'Best Web Developer Footer Legal' );

        $home = $ids['index.html'] ?? $ids['home'] ?? 0;
        $main = array(
            'Home' => $home,
            'About' => $ids['about'] ?? 0,
            'Services' => $ids['services'] ?? 0,
            'Portfolio' => $ids['portfolio'] ?? 0,
            'Pricing' => $ids['pricing'] ?? 0,
            'Blog' => $ids['blog'] ?? 0,
            'FAQs' => $ids['faq'] ?? 0,
            'Contact' => $ids['contact'] ?? 0,
        );
        $services_parent_item = 0;
        foreach ( $main as $label => $post_id ) {
            if ( ! $post_id ) {
                continue;
            }
            $menu_item_id = wp_update_nav_menu_item( $primary_id, 0, array(
                'menu-item-title'     => $label,
                'menu-item-object'    => get_post_type( $post_id ),
                'menu-item-object-id' => $post_id,
                'menu-item-type'      => 'post_type',
                'menu-item-status'    => 'publish',
            ) );
            if ( 'Services' === $label ) {
                $services_parent_item = $menu_item_id;
            }
        }
        $service_slugs = array(
            'search-engine-optimization-services' => 'SEO Services',
            'web-design-development'             => 'Web Design',
            'ui-ux-design'                       => 'UI/UX Design',
            'web-development'                    => 'Backend Development',
            'wordpress-development'              => 'WordPress',
            'ecommerce-development'              => 'Ecommerce / Shopify',
            'digital-marketing-services'         => 'Digital Marketing',
            'email-marketing-near-me'            => 'Email Marketing',
            'content-marketing-services'         => 'Content Marketing',
            'social-media-agency'                => 'Social Media',
            'brand-designs-services'             => 'Brand Design',
            'android-app-development'            => 'Android App Development',
            'illustration-services'              => 'Illustration / 3D',
        );
        foreach ( $service_slugs as $slug => $label ) {
            $post_id = $ids[ $slug ] ?? 0;
            if ( ! $post_id ) {
                continue;
            }
            wp_update_nav_menu_item( $primary_id, 0, array(
                'menu-item-title'     => $label,
                'menu-item-object'    => 'page',
                'menu-item-object-id' => $post_id,
                'menu-item-type'      => 'post_type',
                'menu-item-status'    => 'publish',
                'menu-item-parent-id' => $services_parent_item,
            ) );
        }

        $footer_slugs = array( 'about' => 'About', 'portfolio' => 'Portfolio', 'testimonials' => 'Testimonials', 'blog' => 'Blog', 'faq' => 'FAQs', 'contact' => 'Contact' );
        foreach ( $footer_slugs as $slug => $label ) {
            $this->add_menu_post_item( $footer_id, $label, $ids[ $slug ] ?? 0 );
        }
        foreach ( $service_slugs as $slug => $label ) {
            $this->add_menu_post_item( $services_id, $label, $ids[ $slug ] ?? 0 );
        }
        $legal_slugs = array( 'privacy-policy' => 'Privacy', 'terms-conditions' => 'Terms', 'cookie-policy' => 'Cookies', 'sitemap' => 'Sitemap' );
        foreach ( $legal_slugs as $slug => $label ) {
            $this->add_menu_post_item( $legal_id, $label, $ids[ $slug ] ?? 0 );
        }

        $locations = get_theme_mod( 'nav_menu_locations', array() );
        $locations['primary'] = $primary_id;
        $locations['footer'] = $footer_id;
        $locations['footer_services'] = $services_id;
        $locations['footer_legal'] = $legal_id;
        set_theme_mod( 'nav_menu_locations', $locations );
        return 'Primary, footer, services, and legal menus created';
    }

    private function add_menu_post_item( $menu_id, $label, $post_id ) {
        if ( ! $post_id ) {
            return;
        }
        wp_update_nav_menu_item( $menu_id, 0, array(
            'menu-item-title'     => $label,
            'menu-item-object'    => get_post_type( $post_id ),
            'menu-item-object-id' => $post_id,
            'menu-item-type'      => 'post_type',
            'menu-item-status'    => 'publish',
        ) );
    }

    private function reset_menu( $name ) {
        $menu = wp_get_nav_menu_object( $name );
        if ( $menu ) {
            $items = wp_get_nav_menu_items( $menu->term_id, array( 'post_status' => 'any' ) );
            if ( $items ) {
                foreach ( $items as $item ) {
                    wp_delete_post( $item->ID, true );
                }
            }
            return (int) $menu->term_id;
        }
        return (int) wp_create_nav_menu( $name );
    }

    private function configure_site( $ids ) {
        if ( ! empty( $ids['home'] ) ) {
            update_option( 'show_on_front', 'page' );
            update_option( 'page_on_front', (int) $ids['home'] );
        }
        update_option( 'blogname', 'Best Web Developer' );
        update_option( 'blogdescription', 'Corporate Web Design, Development & Digital Marketing' );
        set_theme_mod( 'bwd_cta_text', 'Free Consultation' );
        set_theme_mod( 'bwd_cta_url', home_url( '/contact/' ) );
        set_theme_mod( 'bwd_contact_email', 'hello@bestwebdeveloper.org' );
        set_theme_mod( 'bwd_service_regions', 'USA & UK service coverage' );
        return ! empty( $ids['home'] ) ? get_the_title( (int) $ids['home'] ) : 'Not set';
    }

    private function create_elementor_templates( $ids, $link_map, $asset_base ) {
        $header = '<nav class="navbar navbar-expand-xl nav-glass"><div class="container-xl"><a class="navbar-brand d-flex align-items-center gap-2" href="' . esc_url( home_url( '/' ) ) . '"><img src="' . esc_url( $asset_base . 'images/best-web-developer-logo.png' ) . '" alt="Best Web Developer" class="brand-logo"></a><div class="ms-auto d-flex flex-wrap gap-3"><a class="nav-link" href="' . esc_url( home_url( '/' ) ) . '">Home</a><a class="nav-link" href="' . esc_url( home_url( '/about/' ) ) . '">About</a><a class="nav-link" href="' . esc_url( home_url( '/services/' ) ) . '">Services</a><a class="nav-link" href="' . esc_url( home_url( '/contact/' ) ) . '">Contact</a><a class="btn btn-orange btn-sm rounded-pill px-4" href="' . esc_url( home_url( '/contact/' ) ) . '">Free Consultation</a></div></div></nav>';
        $footer = '<footer class="footer-creative pt-5"><div class="container-xl py-5"><div class="row g-4"><div class="col-lg-6"><img src="' . esc_url( $asset_base . 'images/best-web-developer-logo.png' ) . '" alt="Best Web Developer" class="footer-logo mb-4"><p class="text-white-50">A corporate web design, development, branding, SEO, and digital marketing partner for measurable growth.</p></div><div class="col-lg-6"><h3 class="footer-title">Start a project</h3><p class="text-white-50">Tell us about your goals and receive a strategy-first consultation.</p><a class="btn btn-orange rounded-pill" href="' . esc_url( home_url( '/contact/' ) ) . '">Request Free Quote</a></div></div></div></footer>';
        $this->upsert_elementor_template( 'BWD Header Template', 'header', $header );
        $this->upsert_elementor_template( 'BWD Footer Template', 'footer', $footer );
    }

    private function upsert_elementor_template( $title, $type, $html ) {
        $existing = get_page_by_title( $title, OBJECT, 'elementor_library' );
        $postarr = array(
            'post_title'   => $title,
            'post_type'    => 'elementor_library',
            'post_status'  => 'publish',
            'post_content' => $html,
        );
        if ( $existing ) {
            $postarr['ID'] = $existing->ID;
            $post_id = wp_update_post( wp_slash( $postarr ) );
        } else {
            $post_id = wp_insert_post( wp_slash( $postarr ) );
        }
        if ( $post_id && ! is_wp_error( $post_id ) ) {
            update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
            update_post_meta( $post_id, '_elementor_template_type', $type );
            update_post_meta( $post_id, '_elementor_version', '3.28.0' );
            update_post_meta( $post_id, '_elementor_data', wp_slash( wp_json_encode( $this->build_elementor_data( $html, $post_id ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) ) );
        }
    }
}

new BWD_Site_Importer();
