=== Best Web Developer Site Importer ===
Contributors: bestwebdeveloper
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later

One-click importer for the Best Web Developer Elementor corporate theme.

== Installation ==
1. Upload and activate the Best Web Developer Elementor Theme.
2. Upload and activate this plugin.
3. Go to Appearance > BWD Site Importer.
4. Click Generate / Update Full Website.
5. Edit each imported page with Elementor.

== What it creates ==
- Homepage, About, Services, Contact, Pricing, FAQ, legal and sitemap pages.
- Full service page set.
- Portfolio pages.
- Blog posts and categories.
- Main header menu, footer menu, footer services menu, and footer legal menu.
- Elementor data for every imported page/post, with each HTML section split into an editable Elementor HTML widget section.
- SEO metadata for Yoast, Rank Math, AIOSEO, and fallback theme output.
- Schema JSON where present in the original HTML.
