=== Best Web Developer Site Importer ===
Contributors: bestwebdeveloper
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPL-2.0-or-later

One-click importer for the Best Web Developer Elementor corporate theme with separate Rank Math SEO/GEO/AEO import tooling.

== Installation ==
1. Upload and activate the Best Web Developer Elementor Theme.
2. Install and activate Elementor.
3. Install and activate Rank Math SEO if you want Rank Math fields visible immediately.
4. Upload and activate this plugin.
5. Go to Appearance > BWD Site Importer.
6. Click Generate / Update Full Website.
7. Click Import / Update Rank Math SEO, GEO & AEO for All Pages.
8. Optionally run Import SEO Only for individual pages from the table.

== What it creates ==
- Homepage, About, Services, Contact, Pricing, FAQ, legal and sitemap pages.
- Full service page set.
- Portfolio pages.
- Blog posts and categories.
- Main header menu, footer menu, footer services menu, and footer legal menu.
- Elementor data for every imported page/post, with each HTML section split into an editable Elementor HTML widget section.
- Rank Math SEO title, description, focus keywords, canonical URL, robots, advanced robots, social metadata, and score helper metadata.
- GEO/entity summaries and AEO quick-answer FAQ blocks.
- Enhanced schema JSON-LD for Organization, WebSite, WebPage, Service, Article, CreativeWork, LocalBusiness, BreadcrumbList, and FAQPage.
- Yoast and AIOSEO fallback fields.
